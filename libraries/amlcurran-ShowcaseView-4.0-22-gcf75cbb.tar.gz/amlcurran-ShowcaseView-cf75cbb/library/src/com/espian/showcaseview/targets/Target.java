package com.espian.showcaseview.targets;

import android.graphics.Point;

public interface Target {
    public Point getPoint();
}
